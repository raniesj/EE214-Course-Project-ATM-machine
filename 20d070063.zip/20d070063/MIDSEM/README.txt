Dear All,

Open the folder. This project DOES NOT have DUT and Testbench, so you have to add those files.  
The tracefile is already present in the folder. 

DO NOT CHANGE or try to understand div.vhd during the exam. 

Files 

ATM: main design file
div: division entitythe input format as dividend(Numerator
of 8 bit), divisor(denominator of 8 bit), remainder and quotient in a single vector(16 bit
with higher 8 bit as remainder and lower 8 bit as quotient).

> Steps to run.


Describe your design in VHDL in a given space.
add DUT and Testbench.
Compile and Test your design

you have to rename this folder to <rollNo_name> and upload on given link. 